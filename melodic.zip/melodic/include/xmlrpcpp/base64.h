#error This header was removed due to licensing issues. \
Please use a dedicated base64 library if you need one for your own project. \
See https://github.com/ros/ros_comm/pull/1046 for more details.
