# generated from rosbash/env-hooks/15.rosbash.bash.em

if [ -z "$CATKIN_ENV_HOOK_WORKSPACE" ]; then
  CATKIN_ENV_HOOK_WORKSPACE="/opt/ros/melodic"
fi
. "$CATKIN_ENV_HOOK_WORKSPACE/share/rosbash/rosbash"
